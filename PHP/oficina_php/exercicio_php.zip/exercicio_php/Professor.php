<?php

//3- Cada professor tem nome, idade e disciplinas(array de objeto)
class Professor extends Pessoa
{
    public array $disciplinas;
    
    public function __construct(string $nome, int $idade, array $disciplinas)
    {
        parent::__construct($nome, $idade);
        $this->disciplinas = $disciplinas;
    }

    public function adicionarDisciplinas(Disciplina $disciplina)
    {
        $this->disciplinas[] = $disciplina;
    }

    public function getInfo()
    {
        return "Nome: {$this->nome} Idade: {$this->idade} Disciplinas: {$this->disciplinas}";
    }
}