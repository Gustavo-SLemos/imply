<?php

/*1- uma faculdade possui disciplina, onde cada aula possui um professor e N alunos
2- Cada aluno tem nome, idade, matricula e notas(array de float)
3- Cada professor tem nome, idade e disciplinas(array de objeto)
4- Cada disciplina tem nome, carga horária, professor e alunos(array de obejtos)
5- Salvar esses dados em um arquivo JSON conforme hierarquia de dados. */

require_once 'Pessoa.php';
require_once 'Aluno.php';
require_once 'Professor.php';
require_once 'Disciplina.php';


$aluno1 = new Aluno("Gustavo", 40, 1000, [8.5, 9.8, 10.0]);
$aluno2 = new Aluno("Igor", 30, 2000, [9.0, 9.2, 10.0]);
$professor1 = new Professor("Francisco", 53, []);
$disciplina1 = new Disciplina("Matemática", 30, $professor1, [$aluno1, $aluno2]);
$disciplina2 = new Disciplina("Português", 30, $professor1, [$aluno1, $aluno2]);
$professor1->adicionarDisciplinas($disciplina1, $disciplina2);

echo "<pre>";
var_dump($professor1);
var_dump($disciplina1, $disciplina2);
echo "</pre>";

/*
echo "<pre>";
echo "<p>Nome: $aluno1->nome </p>";
echo "<p>Idade: $aluno1->idade </p>";
echo "<p>Matrícula: $aluno1->matricula </p>";
echo "<p>Notas: " . implode(", ", $aluno1->notas) . "</p>";
echo "<hr>";
echo "<p>Nome: $aluno2->nome </p>";
echo "<p>Idade: $aluno2->idade </p>";
echo "<p>Matrícula: $aluno2->matricula </p>";
echo "<p>Notas: " . implode(", ", $aluno2->notas) . "</p>";
echo "</pre>";*/

$dados = [$aluno1, $aluno2, $disciplina1, $disciplina2, $professor1];

$jsonData = json_encode($dados);

file_put_contents('dados.json', $jsonData);