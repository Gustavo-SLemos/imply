<?php

//2- Cada aluno tem nome, idade, matricula e notas(array de float)
class Aluno extends Pessoa
{
    public int $matricula;
    public array $notas;


public function __construct(string $nome, int $idade, int $matricula, array $notas)
{
    parent::__construct($nome, $idade);
    $this->matricula = $matricula;
    $this->notas = $notas;
}

public function getInfo()
{
    return "Nome: {$this->nome} Idade: {$this->idade} Matricula: {$this->matricula} Notas: {$this->notas}";
}
}